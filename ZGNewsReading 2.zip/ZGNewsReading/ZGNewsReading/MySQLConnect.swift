//
//  File.swift
//  ZGNewsReading
//
//  Created by 刘铸耿 on 2021/4/14.
//

import Foundation

class MySQLConnect {
    var host: String {
        get {
            return "127.0.0.1"
        }
    }
    var port: String {
        get {
            return "3306"
        }
    }
    var user: String {
        get {
            return "root"
        }
    }
    var password: String {
        get {
            return "pi=3.1415926"
        }
    }
}
